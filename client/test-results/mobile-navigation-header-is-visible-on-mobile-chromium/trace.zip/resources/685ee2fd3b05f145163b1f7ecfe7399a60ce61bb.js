"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["layouts__index"],{

/***/ "./src/layouts/index.tsx":
/*!*******************************!*\
  !*** ./src/layouts/index.tsx ***!
  \*******************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Layout; }
/* harmony export */ });
/* harmony import */ var umi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! umi */ "./src/.umi/exports.ts");
/* harmony import */ var mf_antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mf/antd */ "webpack/container/remote/mf/antd");
/* harmony import */ var mf_antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mf_antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mf_dayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mf/dayjs */ "webpack/container/remote/mf/dayjs");
/* harmony import */ var mf_dayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mf_dayjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_less_modules__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index.module.less?modules */ "./src/layouts/index.module.less?modules");
/* harmony import */ var mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! mf/C:/Users/GhostCloud/Desktop/test/client/node_modules/.pnpm/react@18.3.1/node_modules/react/jsx-dev-runtime */ "webpack/container/remote/mf/C:/Users/GhostCloud/Desktop/test/client/node_modules/.pnpm/react@18.3.1/node_modules/react/jsx-dev-runtime");
/* harmony import */ var mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/.pnpm/@umijs+react-refresh-webpac_1b17d2c8e069162e7f1279b1a7a4e7c1/node_modules/@umijs/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/.pnpm/@umijs+react-refresh-webpac_1b17d2c8e069162e7f1279b1a7a4e7c1/node_modules/@umijs/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js */ "./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js");

var _jsxFileName = "C:\\Users\\GhostCloud\\Desktop\\test\\client\\src\\layouts\\index.tsx",
  _s = __webpack_require__.$Refresh$.signature();





function Layout() {
  _s();
  var navigate = (0,umi__WEBPACK_IMPORTED_MODULE_0__.useNavigate)();
  var location = (0,umi__WEBPACK_IMPORTED_MODULE_0__.useLocation)();
  var today = mf_dayjs__WEBPACK_IMPORTED_MODULE_2___default()().format('YYYY-MM-DD');
  var thisMonth = mf_dayjs__WEBPACK_IMPORTED_MODULE_2___default()().format('YYYY-MM');
  var thisYear = mf_dayjs__WEBPACK_IMPORTED_MODULE_2___default()().format('YYYY');
  var isActive = function isActive(prefix) {
    return location.pathname.startsWith(prefix);
  };
  return /*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
    className: _index_module_less_modules__WEBPACK_IMPORTED_MODULE_3__["default"].layout,
    children: [/*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("header", {
      className: _index_module_less_modules__WEBPACK_IMPORTED_MODULE_3__["default"].header,
      children: [/*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: _index_module_less_modules__WEBPACK_IMPORTED_MODULE_3__["default"].logo,
        children: "\u8BA1\u5212\u7BA1\u7406"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("nav", {
        className: _index_module_less_modules__WEBPACK_IMPORTED_MODULE_3__["default"].nav,
        children: [/*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(mf_antd__WEBPACK_IMPORTED_MODULE_1__.Button, {
          type: isActive('/plans/year') ? 'primary' : 'text',
          onClick: function onClick() {
            return navigate("/plans/year/".concat(thisYear));
          },
          children: "\u5E74"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(mf_antd__WEBPACK_IMPORTED_MODULE_1__.Button, {
          type: isActive('/plans/month') ? 'primary' : 'text',
          onClick: function onClick() {
            return navigate("/plans/month/".concat(thisMonth));
          },
          children: "\u6708"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(mf_antd__WEBPACK_IMPORTED_MODULE_1__.Button, {
          type: isActive('/plans/day') ? 'primary' : 'text',
          onClick: function onClick() {
            return navigate("/plans/day/".concat(today));
          },
          children: "\u65E5"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("main", {
      className: _index_module_less_modules__WEBPACK_IMPORTED_MODULE_3__["default"].main,
      children: /*#__PURE__*/(0,mf_C_Users_GhostCloud_Desktop_test_client_node_modules_pnpm_react_18_3_1_node_modules_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(umi__WEBPACK_IMPORTED_MODULE_0__.Outlet, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 5
  }, this);
}
_s(Layout, "VDZHUspDq9N5O9RWjniBrjgIdAA=", false, function () {
  return [umi__WEBPACK_IMPORTED_MODULE_0__.useNavigate, umi__WEBPACK_IMPORTED_MODULE_0__.useLocation];
});
_c = Layout;
var _c;
__webpack_require__.$Refresh$.register(_c, "Layout");

var $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
var $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		var errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		var testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/layouts/index.module.less?modules":
/*!***********************************************!*\
  !*** ./src/layouts/index.module.less?modules ***!
  \***********************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin
/* harmony default export */ __webpack_exports__["default"] = ({"layout":"layout___pF4Ht","header":"header___vCPcP","logo":"logo___NdMZB","nav":"nav___Igyfb","main":"main___bxqJI"});
    if(true) {
      // 1782724045269
      var cssReload = __webpack_require__(/*! ../../node_modules/.pnpm/@umijs+bundler-webpack@4.6._775a450eb9e30cb7f5a068446cb138e8/node_modules/@umijs/bundler-webpack/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ "./node_modules/.pnpm/@umijs+bundler-webpack@4.6._775a450eb9e30cb7f5a068446cb138e8/node_modules/@umijs/bundler-webpack/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js")(module.id, {"publicPath":"./","emit":true,"esModule":true,"locals":true});
      module.hot.dispose(cssReload);
      
    }
  

/***/ })

}]);
//# sourceMappingURL=layouts__index.async.js.map